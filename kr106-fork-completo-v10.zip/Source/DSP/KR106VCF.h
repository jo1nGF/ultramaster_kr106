#pragma once

#include <cmath>
#include <algorithm>
#include <cstring>
#include <cstdint>

// BA662 feedback architecture: the hardware attenuates the LP4 output
// 67:1 (R3 100K / R1 1.5K) before the differential pair tanh, placing
// the tanh argument at ~0.26 during self-oscillation — barely nonlinear.
// A single memoryless scaled tanh (kFbScale=4.2) replaces the previous
// envelope-based amplitude control. Harmonic purity (H3 ≈ -48 dB),
// flat amplitude across frequency and resonance, pitch accuracy (±3 cents),
// and saw/oscillation level matching all fall out of the weak-drive
// physics rather than requiring per-parameter tuning.

namespace kr106 {

// ============================================================
// Inline half-band polyphase IIR resampler (replaces HIIR)
// ============================================================
// 12-coefficient allpass polyphase network for 2x up/downsampling.
// Same algorithm and coefficients as Laurent de Soras' HIIR library (WTFPL).
static constexpr int kNumResamplerCoefs = 12;

struct Upsampler2x
{
  float coef[kNumResamplerCoefs] = {};
  float x[kNumResamplerCoefs] = {};
  float y[kNumResamplerCoefs] = {};

  void set_coefs(const double c[kNumResamplerCoefs])
  {
    for (int i = 0; i < kNumResamplerCoefs; i++)
      coef[i] = static_cast<float>(c[i]);
  }

  void clear_buffers()
  {
    memset(x, 0, sizeof(x));
    memset(y, 0, sizeof(y));
  }

  void process_sample(float& out_0, float& out_1, float input)
  {
    float even = input;
    float odd = input;
    // Process pairs of allpass stages
    for (int i = 0; i < kNumResamplerCoefs; i += 2)
    {
      float t0 = (even - y[i]) * coef[i] + x[i];
      float t1 = (odd - y[i + 1]) * coef[i + 1] + x[i + 1];
      x[i] = even;   x[i + 1] = odd;
      y[i] = t0;     y[i + 1] = t1;
      even = t0;     odd = t1;
    }
    out_0 = even;
    out_1 = odd;
  }
};

struct Downsampler2x
{
  float coef[kNumResamplerCoefs] = {};
  float x[kNumResamplerCoefs] = {};
  float y[kNumResamplerCoefs] = {};

  void set_coefs(const double c[kNumResamplerCoefs])
  {
    for (int i = 0; i < kNumResamplerCoefs; i++)
      coef[i] = static_cast<float>(c[i]);
  }

  void clear_buffers()
  {
    memset(x, 0, sizeof(x));
    memset(y, 0, sizeof(y));
  }

  float process_sample(const float in[2])
  {
    float spl_0 = in[1];
    float spl_1 = in[0];
    for (int i = 0; i < kNumResamplerCoefs; i += 2)
    {
      float t0 = (spl_0 - y[i]) * coef[i] + x[i];
      float t1 = (spl_1 - y[i + 1]) * coef[i + 1] + x[i + 1];
      x[i] = spl_0;   x[i + 1] = spl_1;
      y[i] = t0;       y[i + 1] = t1;
      spl_0 = t0;     spl_1 = t1;
    }
    return 0.5f * (spl_0 + spl_1);
  }
};

// ============================================================
// 4-pole TPT Cascade LPF (models IR3109 OTA filter)
// ============================================================
// Four 1-pole trapezoidal integrators with global resonance feedback.
// State variables are integrator outputs — coefficient-independent,
// so per-sample cutoff modulation is artifact-free. No sin/cos needed.
struct VCF
{
  float mS[4] = {}; // integrator states
  bool mOTASaturation = true;   // per-stage OTA tanh nonlinearity (IR3109 model)
  bool mJ106Res = false;         // true = J106 resonance curve, false = J6 (calibrated)
  int mOversample = 4;           // 2 or 4 — runtime selectable
  uint32_t mNoiseSeed = 123456789u; // thermal noise PRNG state
  float mInputEnv = 0.f;           // peak envelope follower for noise suppression
  float mEnvDecay = 0.999f;        // per-sample decay for mInputEnv (22ms time constant)
  float mFreqComp = 1.f;           // cached FreqCompensation at base sample rate
  float mSampleRate = 44100.f;     // cached for SetOversample()

  // Two cascaded 2x polyphase stages (used as 1+1 for 4x, or just 1 for 2x).
  Upsampler2x mUp1, mUp2;
  Downsampler2x mDown1, mDown2;

  VCF()
  {
    static constexpr double kCoeffs2x[12] = {
      0.036681502163648017, 0.13654762463195794, 0.27463175937945444,
      0.42313861743656711, 0.56109869787919531, 0.67754004997416184,
      0.76974183386322703, 0.83988962484963892, 0.89226081800387902,
      0.9315419599631839,  0.96209454837808417, 0.98781637073289585
    };
    mUp1.set_coefs(kCoeffs2x);
    mUp2.set_coefs(kCoeffs2x);
    mDown1.set_coefs(kCoeffs2x);
    mDown2.set_coefs(kCoeffs2x);
  }

  void Reset()
  {
    mS[0] = mS[1] = mS[2] = mS[3] = 0.f;
    mUp1.clear_buffers();
    mUp2.clear_buffers();
    mDown1.clear_buffers();
    mDown2.clear_buffers();
  }

  void SetSampleRate(float sampleRate)
  {
    mSampleRate = sampleRate;
    mEnvDecay = expf(-1.f / (0.022f * sampleRate * static_cast<float>(mOversample)));
  }

  void SetOversample(int factor)
  {
    int prev = mOversample;
    mOversample = (factor <= 1) ? 1 : (factor == 2) ? 2 : 4;
    mEnvDecay = expf(-1.f / (0.022f * mSampleRate * static_cast<float>(mOversample)));
    // Don't reset filter state (mS) — preserve pitch continuity.
    // Only clear stage-2 resamplers when switching to 4x, since they were
    // idle during 2x and may contain stale data.
    if (mOversample == 4 && prev == 2)
    {
      mUp2.clear_buffers();
      mDown2.clear_buffers();
    }
  }

  // OTA differential-pair tanh (Padé approximant of tanh(x)).
  // Used in two places: (1) per-stage IR3109 OTA saturation in NLStage,
  // scaled by kOTAScale, and (2) the BA662 feedback path, scaled by
  // kFbScale to model the R3(100K)/R1(1.5K) voltage divider that
  // attenuates the LP4 output before the BA662 differential pair.
  static float OTASat(float x)
  {
    if (x > 3.f) return 1.f;
    if (x < -3.f) return -1.f;
    float x2 = x * x;
    return x * (27.f + x2) / (27.f + 9.f * x2);
  }

  // Derivative of OTASat (sech² approximant), for Newton-Raphson.
  static float OTASatDeriv(float x)
  {
    if (x > 3.f || x < -3.f) return 0.f;
    float x2 = x * x;
    float d = 27.f + 9.f * x2;
    return 27.f * (27.f - 3.f * x2) / (d * d);
  }

  // Resonance slider → feedback gain k.
  // Juno-6 (calibrated from hardware, March 2026):
  //   Saw C1 (32.7 Hz) through VCF, LFO sweep across full cutoff range,
  //   recorded at R=0/3/5/7 via direct line out at 88.2 kHz.
  //   Filter response extracted by dividing out 1/n saw spectrum at each
  //   harmonic, then matching transition-region slope (+1 oct past -6dB)
  //   against the 4-pole TPT cascade simulation (2x oversampled).
  //
  //   R=3 (res=0.3): k ≈ 0.91, measured slope ≈ -18.9 dB/oct
  //   R=5 (res=0.5): k ≈ 1.94, measured slope ≈ -22.7 dB/oct
  //   R=7 (res=0.7): k ≈ 3.52, measured slope ≈ -26.8 dB/oct
  //   R=0 slope (-13.1 dB/oct) matches sim with k=0 (no fit needed).
  //
  // Juno-6: exponential resonance curve. Shape from hardware measurements;
  // kMax > 4.0 to compensate for tanh stage saturation absorbing feedback
  // energy (linear k=4 would self-oscillate, but our nonlinear stages need
  // ~5.0 to sustain oscillation). Gives 3-7 dB peaks at moderate settings.
  //
  // Hardware self-oscillation measurements (Juno-6 SN#193284, March 2026)
  // show flat amplitude (±0.5 dB) across 112 Hz–14 kHz at res=1.0 and
  // res=0.9. No frequency-dependent k correction is needed. The BA662
  // feedback tanh (weakly driven via the 100K:1.5K voltage divider)
  // stabilizes the limit cycle amplitude inherently.
  static float ResK_J6(float res)
  {
    static constexpr float kShape = 2.128f;
    static constexpr float kNorm = 0.811f;
    return kNorm * (expf(kShape * res) - 1.f);
  }

  static float ResK_J106(float res)
  {
    // Fitted to hardware peak amplitudes from noise grid measurements
    // (SN#193284). Small-signal k(res) extracted by inverting the
    // 4-pole TPT cascade peak response, scaled 1.24x to compensate
    // for OTA compression underestimate in extraction. RMSE 0.07
    // over res >= 28 (pre-scale). k(1.0) = 4.19, threshold ~ res 0.9.
    float r = res;
    float r2 = r * r;
    float r3 = r2 * r;
    float r4 = r2 * r2;
    return 1.24f * (4.7116f * r - 6.5743f * r2 + 13.4633f * r3 - 8.2197f * r4);
  }

  // Frequency compensation: multiplier applied to g (integrator coeff)
  // after the bilinear warp, correcting the effective cutoff frequency.
  //
  // Two effects shift the cutoff away from the target:
  //   1. Cascade droop: 4 identical poles in series place the -3dB point
  //      at 0.435× the individual pole frequency (k=0). Well-known from
  //      Zavalishin's "Art of VA Filter Design" — needs ~1.96× boost.
  //
  //   2. OTASat compression: at high k, the per-stage tanh nonlinearity
  //      reduces effective integrator gain (describing function gain < 1),
  //      pulling the cutoff frequency below target. The compression is
  //      amplitude-dependent but approximately constant for a given k
  //      (the limit cycle amplitude is set by the tanh).
  //
  // Applied to g (post-warp) rather than frq (pre-warp) so the tan()
  // bilinear transform sees the true frequency. This makes the
  // compensation sample-rate independent — verified by sweep tests at
  // 44.1 kHz and 96 kHz showing < 60 cent divergence vs 500+ cents
  // when compensating frq directly.
  //
  // Frequency-dependent cutoff compensation for the 4-pole digital filter.
  //
  // The bilinear transform warps the -3dB point of the 4-pole cascade
  // in a frequency-dependent way. Fit to J106 hardware -3dB measurements
  // (noise through VCF, test mode 3, KBD=max, R=0, 6 notes C2-C7).
  //
  // Power law: 2.004 * frq^0.162
  //   Low frequencies get reduced (~0.7x), high frequencies boosted (~1.2x).
  // At high resonance (k>3), the filter self-oscillates and the peak
  // frequency IS the pole frequency -- compensation must fade to 1.0
  // or the oscillation pitch shifts. Blend uses k^2 for a slow ramp
  // that preserves low-Q correction through mid-resonance.
  //
  // frq = cutoff / sampleRate (0..1 normalized)
  static float FreqCompensation(float k, float frq)
  {
    float lowQ = 2.004f * powf(std::max(frq, 1e-5f), 0.162f);
    // Slow blend: k^2/16 reaches 1.0 at k=4
    float blend = std::min(k * k * 0.0625f, 1.f);
    return lowQ + blend * (1.f - lowQ);
  }

  // Hardware-calibrated version: boosts pole frequency at low cutoff to
  // match passband levels from hardware noise sweep measurements.
  // Power law 0.4128 * frq^-0.2107 fitted to match hardware at VCF bytes
  // 0-72 (R=0), clamped to 0.80 at high frequencies where the original
  // compensation was overshooting. At high resonance, blends toward 1.0
  // to preserve self-oscillation pitch accuracy.
  // Non-optimized path: use the formula approximation.
  // The optimized VCF uses a 2D lookup table instead.
  static float FreqCompensationClamped(float k, float frq)
  {
    float lowQ = std::max(1.0f, 0.42f * powf(std::max(frq, 1e-6f), -0.12f));
    float logdist = logf(std::max(frq, 1e-6f) / 0.012f);
    lowQ += 0.20f * expf(-logdist * logdist / 1.0f);
    float blend = std::min(k * k * 0.0625f, 1.f);
    return lowQ + blend * (1.f - lowQ);
  }

  // Soft-clip resonance above k=3.0 (OTA gain compression at high feedback).
  static float SoftClipK(float k)
  {
    if (k > 3.0f)
    {
      float excess = k - 3.0f;
      k = 3.0f + excess / (1.0f + excess * 0.2f);
    }
    return std::min(k, 6.6f);
  }

  // Input Q compensation: BA662 differential topology feeds input through
  // R5(47K) alongside LP4 feedback on R3(100K). Higher resonance boosts
  // the input, counteracting passband volume drop.
  //
  // Frequency-dependent gain: OTA bias current affects passband transmission.
  // At low cutoff (small frq) the OTAs run at lower bias and pass more signal
  // per unit input; at high cutoff they saturate earlier. Power law fitted to
  // 10x10 hardware noise sweep (96 kHz, R=0). Crossover at frq~0.0045 (427 Hz).
  static float InputComp(float k, float frq)
  {
      float qComp = 0.379f + 0.087f * k;
      float freqGain = powf(std::max(frq, 1e-6f) * (1.f / 0.00445f), -0.10f);
      freqGain = std::clamp(freqGain, 0.65f, 1.2f);
      return qComp * freqGain;
  }

  static constexpr float kOTAScaleBase = 0.35f;

  static float OTAScaleForFreq(float frq, float resByte = 0.f)
  {
    float scale = kOTAScaleBase;
    if (frq < 0.005f)
    {
      float blend = std::max(frq / 0.005f, 0.15f);
      scale *= blend;
    }
    // At high resonance, restore full OTA drive for accurate self-osc pitch
    if (resByte > 0.f)
    {
      float resK = 1.024f * (expf(2.128f * resByte / 127.f) - 1.f);
      float resBlend = std::min(resK * resK * 0.0625f, 1.f);
      scale = scale + resBlend * (kOTAScaleBase - scale);
    }
    return scale;
  }

  // Nonlinear one-pole OTA-C stage: solves y = s + g*tanh(x - y)
  // via one Newton-Raphson iteration from the linear TPT estimate.
  static float NLStage(float& s, float x, float g, float g1, float otaScale)
  {
      float y = s + g1 * (x - s);
      float diff = x - y;
      float sd = diff * otaScale;
      float t = OTASat(sd) / otaScale;
      float f = y - s - g * t;
      float df = 1.f + g * OTASatDeriv(sd);
      y -= f / df;
      s = 2.f * y - s;
      return y;
  }

  // frq: normalized cutoff [0, ~0.9] where 1.0 = Nyquist (base rate)
  // res: resonance amount [0, 1]
  float Process(float input, float frq, float res)
  {
    frq = std::min(frq, 0.95f);

    // Compute FreqCompensation at the 4x-equivalent rate (matches tuning).
    // Always use frq/4 regardless of actual oversample setting so the
    // compensation curve is consistent across all modes.
    float k = mJ106Res ? ResK_J106(res) : ResK_J6(res);
    if (!mJ106Res) k = SoftClipK(k);
    if (frq > 0.5f)
      k *= std::max(1.f - (frq - 0.5f) * 1.f, 0.5f);
    mFreqComp = FreqCompensationClamped(k, frq * 0.25f);

    if (mOversample == 4)
      return Process4x(input, frq, res);
    else if (mOversample == 2)
      return Process2x(input, frq, res);
    else
      return ProcessSample(input, frq, res);
  }

private:
  // 2x oversampled: upsample, filter 2 samples, downsample
  float Process2x(float input, float frq, float res)
  {
    float up[2], down[2];
    mUp1.process_sample(up[0], up[1], input);

    float frq2x = frq * 0.5f;
    down[0] = ProcessSample(up[0], frq2x, res);
    down[1] = ProcessSample(up[1], frq2x, res);

    return mDown1.process_sample(down);
  }

  // 4x oversampled: 1x→2x→4x up, filter 4 samples, 4x→2x→1x down
  float Process4x(float input, float frq, float res)
  {
    float frq4x = frq * 0.25f;

    // Stage 1 upsample: 1x → 2x
    float up2x[2];
    mUp1.process_sample(up2x[0], up2x[1], input);

    // Stage 2 upsample + filter: 2x → 4x, process 4 samples
    float down4x[2], down2x[2];

    float up4x_a[2];
    mUp2.process_sample(up4x_a[0], up4x_a[1], up2x[0]);
    down4x[0] = ProcessSample(up4x_a[0], frq4x, res);
    down4x[1] = ProcessSample(up4x_a[1], frq4x, res);
    down2x[0] = mDown2.process_sample(down4x);

    float up4x_b[2];
    mUp2.process_sample(up4x_b[0], up4x_b[1], up2x[1]);
    down4x[0] = ProcessSample(up4x_b[0], frq4x, res);
    down4x[1] = ProcessSample(up4x_b[1], frq4x, res);
    down2x[1] = mDown2.process_sample(down4x);

    // Stage 2 downsample: 2x → 1x
    return mDown1.process_sample(down2x);
  }

  // Internal per-sample filter at the oversampled rate
  float ProcessSample(float input, float frq, float res)
  {
    // Adaptive thermal noise: models BA662/IR3109 OTA bias current noise.
    // High level when filter is quiet (to seed self-oscillation startup),
    // fades to inaudible once oscillation is established. This keeps
    // pure self-oscillation patches clean while still providing reliable
    // oscillation seeding.
    mNoiseSeed = mNoiseSeed * 196314165u + 907633515u;
    float white = static_cast<float>(mNoiseSeed) / static_cast<float>(0xFFFFFFFFu) * 2.f - 1.f;
    mInputEnv = std::max(fabsf(input), mInputEnv * mEnvDecay);
    float stateEnergy = fabsf(mS[0]) + fabsf(mS[1]) + fabsf(mS[2]) + fabsf(mS[3]);
    float energy = std::max(mInputEnv, stateEnergy);
    float noiseLevel = 1e-2f / (static_cast<float>(mOversample) * (1.f + energy * 1000.f));
    input += white * noiseLevel;

    // Resonance CV: external transistor feeds BA662 OTA control current.
    float k = mJ106Res ? ResK_J106(res) : ResK_J6(res);
    if (!mJ106Res) k = SoftClipK(k);
    if (frq > 0.5f)
      k *= std::max(1.f - (frq - 0.5f) * 1.f, 0.5f);

    // Clamp frq for the bilinear transform — prevents tan() from
    // blowing up near Nyquist.
    float frqUnclamped = frq;
    frq = std::min(frq, 0.85f);
    float g = tanf(frq * static_cast<float>(M_PI) * 0.5f);
    g *= mFreqComp; // pre-computed at base rate in Process()

    // Precompute gains for the 4-pole cascade solution
    float g1 = g / (1.f + g);  // one-pole gain

    // Linear cascade: the predictor is exact, so the filter is
    // unconditionally stable regardless of modulation speed.
    float G = g1 * g1 * g1 * g1;

    float S = mS[0] * g1 * g1 * g1 + mS[1] * g1 * g1 + mS[2] * g1 + mS[3];

    float comp = InputComp(k, frq);

    // BA662 tanh saturation is set by 2*Vt, independent of IR3109 bias
    // current -- amplitude is naturally flat.
    float kFbScale = 4.20f * std::clamp((k - 2.5f) * 1.0f, 0.3f, 1.f);
    float fbSig = OTASat(S * kFbScale) / kFbScale;

    float u = (input * comp - k * fbSig) / (1.f + k * G);

    float lp4;
    if (mOTASaturation)
    {
      // Describing function pitch compensation. Constant 0.6 gives
      // +/-2 cents from 220 Hz up at R=1.0.
      float stateAmp = fabsf(mS[3]);
      float dfGain = 1.f / sqrtf(1.f + 0.6f * stateAmp * stateAmp);
      dfGain = std::max(dfGain, 0.65f);

      // Fade correction off near Nyquist to prevent aliasing feedback.
      // At 4x/44.1k: frq=0.08 ≈ 7kHz, frq=0.12 ≈ 10.6kHz. Full
      // correction below 7kHz, linear fade to zero at 10.6kHz.
      float hfFade = std::clamp((0.12f - frq) * 25.f, 0.f, 1.f);
      dfGain = 1.f - hfFade * (1.f - dfGain);
      float g1NL = g1 / dfGain;
      g1NL = std::min(g1NL, 0.98f);

      float gNL = g1NL / (1.f - g1NL);
      float ota = OTAScaleForFreq(frq);

      float lp1 = NLStage(mS[0], u, gNL, g1NL, ota);
      float lp2 = NLStage(mS[1], lp1, gNL, g1NL, ota);
      float lp3 = NLStage(mS[2], lp2, gNL, g1NL, ota);
      lp4 = NLStage(mS[3], lp3, gNL, g1NL, ota);
    }
    else
    {
      // Linear stages: standard TPT trapezoidal integrators without
      // per-stage OTA saturation. The 4-pole cascade solution (G, S, u)
      // above is exact for linear stages, so no Newton-Raphson is needed.
      // The feedback path uses the BA662 scaled tanh, which at low drive
      // levels is nearly linear — the tiny g1 boost (0.1% at max k)
      // compensates for the residual nonlinearity, keeping the
      // self-oscillation frequency on target.
      float g1L = g1 * (1.f + k * 0.0003f);
      float v, s;
      s = mS[0]; v = g1L * (u - s);   mS[0] = s + 2.f * v; float lp1 = s + v;
      s = mS[1]; v = g1L * (lp1 - s); mS[1] = s + 2.f * v; float lp2 = s + v;
      s = mS[2]; v = g1L * (lp2 - s); mS[2] = s + 2.f * v; float lp3 = s + v;
      s = mS[3]; v = g1L * (lp3 - s); mS[3] = s + 2.f * v; lp4       = s + v;
    }

    // Flush denormals from integrator states
    for (auto& st : mS)
      if (fabsf(st) < 1e-15f) st = 0.f;

    // Output gain: InputComp scales the input to ~0.38 at k=0 so that
    // passband signals stay in the OTA linear region. Self-oscillation
    // amplitude is set by kFbScale and is independent of input scaling.
    // InputComp * outputGain preserves passband level (1.22x).
    // Self-osc level calibrated from hardware: ~1.07x pulse at R=127.
    // Output attenuation at high freq + high res (matches optimized VCF).
    float frqFactor = std::clamp((frqUnclamped - 0.02f) * 20.f, 0.f, 1.f);
    float resFactor = std::clamp((k - 2.f) * 0.5f, 0.f, 1.f);
    float outputScale = 1.f - frqFactor * resFactor * 0.5f;
    return lp4 * 3.22f * outputScale;
  }
};

} // namespace kr106
